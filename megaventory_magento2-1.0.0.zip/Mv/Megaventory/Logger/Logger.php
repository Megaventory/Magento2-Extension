<?php
namespace Mv\Megaventory\Logger;

class Logger extends \Monolog\Logger
{
}