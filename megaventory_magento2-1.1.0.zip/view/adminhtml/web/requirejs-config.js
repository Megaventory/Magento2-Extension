/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
	 map: {
	        '*': {
	        megaventory: 'Mv_Megaventory/js/megaventory'
	    }
	}
};